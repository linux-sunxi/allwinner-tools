#!/bin/bash
set  -e

appname=`basename $0 | sed s,\.sh$,,`
appdir=bin

dirname=`dirname $0`/$appdir
tmp="${dirname#?}"

if [ "${dirname%$tmp}" != "/" ]; then
	dirname=$PWD/$appdir
fi

LD_LIBRARY_PATH=$dirname
export LD_LIBRARY_PATH
sudo $dirname/$appname "$@" #>/dev/null
